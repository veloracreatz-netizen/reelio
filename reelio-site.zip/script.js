(()=>{
"use strict";
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
const fine=matchMedia("(hover:hover) and (pointer:fine)").matches;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));

/* split headings into words for line reveals */
$$(".split").forEach(h=>{
  const walk=n=>{[...n.childNodes].forEach(c=>{
    if(c.nodeType===3){const f=document.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(t=>{if(!t)return;if(/^\s+$/.test(t)){f.appendChild(document.createTextNode(t));return;}const w=document.createElement("span");w.className="w";const i=document.createElement("span");i.textContent=t;w.appendChild(i);f.appendChild(w);});c.replaceWith(f);}
    else if(c.nodeType===1&&!c.classList.contains("w")) walk(c);});};
  walk(h);
  $$(".w>span",h).forEach((s,i)=>s.style.transitionDelay=(i*55)+"ms");
});

/* reveal on scroll */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target);}}),{rootMargin:"0px 0px -8% 0px",threshold:.12});
$$(".reveal,.split").forEach((el,i)=>{ if(el.classList.contains("reveal")){const sib=[...el.parentElement.children].filter(c=>c.classList.contains("reveal"));el.style.transitionDelay=(sib.indexOf(el)%4*80)+"ms";} io.observe(el);});
requestAnimationFrame(()=>$(".hero h1")&&$(".hero h1").classList.add("in"));

/* header, progress bar, sticky CTA */
const top=$("#top"), bar=$("#progress"), sticky=$("#stickyWa"), hero=$(".hero"), contact=$("#contact");
/* menu */
const mb=$("#menuBtn"), menu=$("#menu");
const setMenu=o=>{mb.setAttribute("aria-expanded",o);mb.setAttribute("aria-label",o?"Close menu":"Open menu");if(o){menu.hidden=false;requestAnimationFrame(()=>menu.classList.add("open"));document.body.style.overflow="hidden";}else{menu.classList.remove("open");menu.hidden=true;document.body.style.overflow="";}};
mb.addEventListener("click",()=>setMenu(mb.getAttribute("aria-expanded")!=="true"));
$$("a",menu).forEach(a=>a.addEventListener("click",()=>setMenu(false)));
addEventListener("keydown",e=>{if(e.key==="Escape")setMenu(false);});

/* ---------- sound: a soft synth pad + shutter tick, never autoplayed ---------- */
let ac=null, master=null, soundOn=false;
const sb=$("#sound");
function startAudio(){
  ac=ac||new (window.AudioContext||window.webkitAudioContext)();
  if(!master){master=ac.createGain();master.gain.value=0;master.connect(ac.destination);
    const lp=ac.createBiquadFilter();lp.type="lowpass";lp.frequency.value=900;lp.connect(master);
    [[110,0],[164.8,3],[220,-4],[277.2,6]].forEach(([f,d])=>{const o=ac.createOscillator();o.type="sawtooth";o.frequency.value=f;o.detune.value=d;const g=ac.createGain();g.gain.value=.05;o.connect(g);g.connect(lp);o.start();
      const l=ac.createOscillator();l.frequency.value=.08+Math.random()*.1;const lg=ac.createGain();lg.gain.value=.03;l.connect(lg);lg.connect(g.gain);l.start();});}
  ac.resume();master.gain.cancelScheduledValues(ac.currentTime);master.gain.linearRampToValueAtTime(.35,ac.currentTime+1.2);
}
function stopAudio(){if(ac&&master){master.gain.cancelScheduledValues(ac.currentTime);master.gain.linearRampToValueAtTime(0,ac.currentTime+.5);}}
function tick(){if(!soundOn||!ac)return;const len=.06,b=ac.createBuffer(1,ac.sampleRate*len,ac.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,4);const s=ac.createBufferSource();s.buffer=b;const g=ac.createGain();g.gain.value=.25;const hp=ac.createBiquadFilter();hp.type="highpass";hp.frequency.value=1800;s.connect(hp);hp.connect(g);g.connect(ac.destination);s.start();}
sb.addEventListener("click",()=>{soundOn=!soundOn;sb.setAttribute("aria-pressed",soundOn);sb.setAttribute("aria-label",soundOn?"Turn sound off":"Turn sound on");try{soundOn?startAudio():stopAudio();}catch(e){}});

/* ---------- hero reel: drag / swipe with momentum + snap, autoplay ---------- */
const stage=$("#stage"), reels=$$(".reel"), N=reels.length;
let moved=false, pos=0, target=0, vel=0, dragging=false, lastX=0, lastT=0, startX=0, startY=0, axis=null, idle=0, active=-1;
const cardW=()=>reels[0].offsetWidth||260;
const wrap=o=>{o=((o%N)+N)%N;return o>N/2?o-N:o;};
function layout(){
  const w=cardW(), sp=w*.62;
  reels.forEach((r,i)=>{
    const o=wrap(i-pos), a=Math.abs(o);
    const x=o*sp, s=1-Math.min(a,3)*.13, ry=clamp(-o*18,-40,40), z=-a*80;
    r.style.transform=`translate3d(${x}px,${a*14}px,${z}px) rotateY(${ry}deg) scale(${s})`;
    r.style.opacity=a>2.6?0:1-Math.max(0,a-1.2)*.45;
    r.style.zIndex=100-Math.round(a*10);
    r.style.filter=a>.5?`brightness(${1-Math.min(a,2)*.28})`:"none";
  });
  const idx=((Math.round(pos)%N)+N)%N;
  if(idx!==active){if(active>=0){reels[active].classList.remove("active");}reels[idx].classList.add("active");active=idx;tick();}
}
function loop(t){
  if(!dragging){
    if(Math.abs(vel)>.0005){target=Math.round(pos+vel*8);vel=0;}
    pos+=(target-pos)*(reduce?1:.09);
    if(Math.abs(target-pos)<.0008)pos=target;
    if(!reduce&&performance.now()-idle>3600&&!document.hidden&&stageVisible){target=Math.round(pos)+1;idle=performance.now();}
  }
  layout();requestAnimationFrame(loop);
}
let stageVisible=true;
new IntersectionObserver(es=>{stageVisible=es[0].isIntersecting;}).observe(stage);
stage.addEventListener("pointerdown",e=>{dragging=true;axis=null;startX=lastX=e.clientX;startY=e.clientY;lastT=performance.now();vel=0;moved=false;});
stage.addEventListener("pointermove",e=>{
  if(!dragging)return;
  if(axis===null){const dx=Math.abs(e.clientX-startX),dy=Math.abs(e.clientY-startY);if(dx<6&&dy<6)return;axis=dx>dy?"x":"y";if(axis==="x"){stage.classList.add("dragging");moved=true;try{stage.setPointerCapture(e.pointerId);}catch(_){}}}
  if(axis!=="x"){dragging=false;return;}
  const now=performance.now(),dx=e.clientX-lastX,dp=-dx/(cardW()*.62);
  pos+=dp;vel=dp/Math.max(1,now-lastT)*16;lastX=e.clientX;lastT=now;target=pos;idle=performance.now();
});
const end=()=>{if(!dragging&&axis!=="x"){axis=null;return;}dragging=false;axis=null;stage.classList.remove("dragging");target=Math.round(pos+clamp(vel*6,-2,2));vel=0;idle=performance.now();};
stage.addEventListener("pointerup",end);stage.addEventListener("pointercancel",end);
stage.addEventListener("click",e=>{if(moved){moved=false;return;}const r=e.target.closest(".reel");if(!r||e.target.closest("button"))return;const i=+r.dataset.i;target=pos+wrap(i-pos);idle=performance.now();});
$("#prev").addEventListener("click",e=>{e.stopPropagation();target=Math.round(target)-1;idle=performance.now();});
$("#next").addEventListener("click",e=>{e.stopPropagation();target=Math.round(target)+1;idle=performance.now();});
stage.addEventListener("keydown",e=>{if(e.key==="ArrowRight"){target=Math.round(target)+1;idle=performance.now();}if(e.key==="ArrowLeft"){target=Math.round(target)-1;idle=performance.now();}});
stage.tabIndex=0;
idle=performance.now();requestAnimationFrame(loop);

/* ---------- pinned Rithm Cafe case study, driven by scroll ---------- */
const res=$("#results"), fol=$("#followers"), posts=$("#posts"), pf=$("#pfFollowers"), fing=$("#following"), handle=$("#handle"), bio=$("#bio"), tb=$("#tagBefore"), ta=$("#tagAfter"), grid=$("#grid"), ge=$("#gridEmpty"), cue=$(".scroll-cue");
const tiles=matchMedia("(min-width:900px)").matches?["latte","rithm","reel-latte","reel-beans","reel-rithm","reel-motion","reel-phone","reel-shoot","latte"]:["latte","rithm","reel-beans","reel-rithm","reel-latte","reel-motion"];
tiles.forEach(t=>{const i=document.createElement("i");i.dataset.bg=`img/${t}.webp`;grid.appendChild(i);});
let tilesLoaded=false;
const fmt=n=>n.toLocaleString("en-IN");
function caseAt(p){
  const q=clamp((p-.18)/.6,0,1), e=1-Math.pow(1-q,3);
  const after=q>0;
  fol.textContent=fmt(Math.round(6000*e));
  posts.textContent=Math.round(45*e);
  pf.textContent=fmt(Math.round(6000*e));
  fing.textContent=after?"12":"1,001";
  handle.textContent=after?"rithmcafe.hyd":"rithm.cafe";
  bio.textContent=after?"RITHM Cafe | Latte Arts Studio · Coffee | Brunches | Art workshops and everything in between":"Film Nagar, Hyd · Cozy cafe";
  tb.classList.toggle("on",!after);ta.classList.toggle("on",after);
  const on=Math.round(e*tiles.length);
  $$("i",grid).forEach((t,k)=>t.classList.toggle("on",k<on));
  ge.style.opacity=after?0:1;
  cue.style.opacity=p>.85?0:1;
}
function onResultsScroll(){
  const r=res.getBoundingClientRect(), total=res.offsetHeight-innerHeight;
  const p=clamp(-r.top/Math.max(1,total),0,1);
  if(!tilesLoaded&&r.top<innerHeight*1.5){$$("i",grid).forEach(t=>t.style.backgroundImage=`url(${t.dataset.bg})`);tilesLoaded=true;}
  caseAt(reduce?1:p);
}

/* ---------- parallax ---------- */
const para=$$(".parallax");
function onParallax(){if(reduce)return;para.forEach(el=>{const r=el.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight)return;const c=(r.top+r.height/2-innerHeight/2);const img=el.querySelector("img");img.style.transform=`translate3d(0,${c*(+el.dataset.speed)}px,0) scale(1.15)`;});}

/* ---------- one scroll handler, rAF throttled ---------- */
let ticking=false;
function onScroll(){
  const y=scrollY, h=document.documentElement.scrollHeight-innerHeight;
  bar.style.transform=`scaleX(${h>0?y/h:0})`;
  top.classList.toggle("scrolled",y>20);
  const heroBottom=hero.offsetTop+hero.offsetHeight*.7, cr=contact.getBoundingClientRect();
  sticky.classList.toggle("show",y>heroBottom&&!(cr.top<innerHeight*.6&&cr.bottom>0));
  onResultsScroll();onParallax();ticking=false;
}
addEventListener("scroll",()=>{if(!ticking){ticking=true;requestAnimationFrame(onScroll);}},{passive:true});
addEventListener("resize",onScroll);onScroll();

/* ---------- desktop tilt + spotlight ---------- */
if(fine&&!reduce){
  $$(".tilt").forEach(el=>{
    el.addEventListener("pointermove",e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;el.style.setProperty("--mx",x*100+"%");el.style.setProperty("--my",y*100+"%");el.style.transform=`perspective(800px) rotateX(${(.5-y)*6}deg) rotateY(${(x-.5)*8}deg) translateY(-4px)`;});
    el.addEventListener("pointerleave",()=>{el.style.transform="";});
  });
}

/* ---------- plan toggle ---------- */
const tg=$(".toggle"), tw=$("#tab-week"), tm=$("#tab-month"), pw=$("#plan-week"), pm=$("#plan-month");
function setPlan(m){tg.classList.toggle("month",m);tw.setAttribute("aria-selected",!m);tm.setAttribute("aria-selected",m);pw.hidden=m;pm.hidden=!m;}
tw.addEventListener("click",()=>setPlan(false));tm.addEventListener("click",()=>setPlan(true));
tg.addEventListener("keydown",e=>{if(e.key==="ArrowRight"||e.key==="ArrowLeft"){const m=!tg.classList.contains("month");setPlan(m);(m?tm:tw).focus();}});

/* ---------- brief builder -> WhatsApp ---------- */
const nameI=$("#bName"), prev=$("#preview"), send=$("#briefSend");
const bizWord={"Café":"a café","Restaurant":"a restaurant","Fashion brand":"a fashion brand","Startup":"a startup","Something else":"a business"};
function buildMsg(){
  const biz=$('[data-group="biz"] .on').textContent, plan=$('[data-group="plan"] .on').textContent, nm=nameI.value.trim();
  let m="Hi REELIO! "+(nm?`I'm ${nm}. `:"")+`I run ${bizWord[biz]||"a business"}`;
  m+= plan==="Not sure yet"?" and I'd like help choosing a plan.":` and I'm interested in the ${plan.replace(" · ₹30,000","")} plan.`;
  prev.textContent=m;send.href="https://wa.me/919381894142?text="+encodeURIComponent(m);
}
$$(".opts").forEach(g=>g.addEventListener("click",e=>{const b=e.target.closest(".opt");if(!b)return;$$(".opt",g).forEach(o=>o.classList.remove("on"));b.classList.add("on");buildMsg();}));
nameI.addEventListener("input",buildMsg);buildMsg();

/* ---------- studio clock (IST) ---------- */
const clk=$("#clock");
function clock(){try{clk.textContent=new Intl.DateTimeFormat("en-IN",{timeZone:"Asia/Kolkata",hour:"2-digit",minute:"2-digit",hour12:true}).format(new Date())+" IST";}catch(e){}}
clock();setInterval(clock,30000);
})();
